package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	public WebDriver driver;

	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "user_email")
	WebElement emailid;

	@FindBy(id = "user_password")
	WebElement password;

	@FindBy(xpath = "//input[@type='submit']")
	WebElement submit;

	public WebElement getEmailId() {
		return emailid;

	}

	public WebElement getPassword() {
		return password;

	}

	public WebElement getLoginButton() {
		return submit;

	}

}
