package login;

import java.io.IOException;
import java.util.List;

import org.testng.TestListenerAdapter;
import org.testng.TestNG;

import com.beust.jcommander.internal.Lists;
//import com.jombay.web.HiveScoreUploadTest;



public class Maintest {

public static void main(String[] args) throws InterruptedException, IOException {

//	TestListenerAdapter tla = new TestListenerAdapter();
//	TestNG testng = new TestNG();
//	testng.setTestClasses(new Class[] { HiveScoreUploadTest.class });
//	testng.addListener(tla);
//	testng.run();
TestListenerAdapter tla = new TestListenerAdapter();
TestNG testng = new TestNG();
List<String> suites = Lists.newArrayList();
suites.add("testng.xml");
testng.setTestSuites(suites);
testng.run();
}
}