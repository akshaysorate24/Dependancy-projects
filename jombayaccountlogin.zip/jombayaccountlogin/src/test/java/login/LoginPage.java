package login;

import org.testng.annotations.Test;

import pageobjects.Login;

import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginPage extends Base {

	@BeforeTest
	void initializeDriver() {
		driver = initialize();

	}

	@Test(priority = 1)
	public void signinTest() throws InterruptedException {
		driver.get("https://companies.ur-nl.com/");
		Login signinObject = new Login(driver);
		Thread.sleep(2000);
		signinObject.getEmailId().sendKeys("review@jombay.com");
		signinObject.getPassword().sendKeys("test123");
		signinObject.getLoginButton().click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Thread.sleep(2000);
	}

	@AfterTest
	public void closeTest() throws InterruptedException {
		Thread.sleep(2000);
		driver.quit();
	}

}
