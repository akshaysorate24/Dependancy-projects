package login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Base {
	public static WebDriver driver; 
	public WebDriver initialize()
	{
		
		System.setProperty("webdriver.chrome.driver","/Users/abhijeetthorat/Desktop/chrome_driver/chromedriver");
		driver=new ChromeDriver();	
		return driver;
	}
	
}
